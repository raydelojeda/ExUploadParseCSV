<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['main_msg_login']='Login to your account';
$lang['main_label_user']='Username';
$lang['main_label_pass']='Password';

