<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['main_msg_login']='Ingrese a su cuenta';
$lang['main_label_user']='Usuario';
$lang['main_label_pass']='Clave';

