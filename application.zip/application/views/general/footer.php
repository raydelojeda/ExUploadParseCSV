</div>
<?php $this->load->view('general/includeJS', $includeJS);?>

</body>
</html>