<?php if(!empty($includeCSS))$this->load->view('general/includeCSS', $includeCSS);?>
<?php if(!empty($includeJS))$this->load->view('general/includeJS', $includeJS);?>