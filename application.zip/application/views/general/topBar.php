<header class="topbar" style="position: fixed;top: 0;width: 100%;">
    <nav class="navbar top-navbar navbar-expand-md navbar-light">
    </nav>
</header>
<div style="position: relative; width: 100%; height: 70px; display: block; vertical-align: baseline; float: none;"></div>

