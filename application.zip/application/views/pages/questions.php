<div class="card1">

    <!-- ============================================================== -->
    <!-- Comment widgets -->
    <!-- ============================================================== -->
    <div class="comment-widgets">
        <!-- Comment Row -->
        <div class="d-flex flex-row comment-row">
            <div class="p-2"><span class="round"><img src="../assets/images/users/1.jpg" alt="user" width="50"></span></div>
            <div class="comment-text w-100">
                <h5>James Anderson</h5>
                <p class="mb-1">Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has beenorem Ipsum is simply dummy text of the printing and type setting industry.</p>
                <div class="comment-footer">
                    <span class="text-muted float-right">April 14, 2016</span>
                    <span class="label label-light-info">Pending</span>
                    <span class="action-icons">
                                                <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-heart"></i></a>
                                            </span>
                </div>
            </div>
        </div>
        <!-- Comment Row -->
        <div class="d-flex flex-row comment-row active">
            <div class="p-2"><span class="round"><img src="../assets/images/users/2.jpg" alt="user" width="50"></span></div>
            <div class="comment-text active w-100">
                <h5>Michael Jorden</h5>
                <p class="mb-1">Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has beenorem Ipsum is simply dummy text of the printing and type setting industry..</p>
                <div class="comment-footer ">
                    <span class="text-muted float-right">April 14, 2016</span>
                    <span class="label label-light-success">Approved</span>
                    <span class="action-icons active">
                                                    <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                    <a href="javascript:void(0)"><i class="icon-close"></i></a>
                                                    <a href="javascript:void(0)"><i class="ti-heart text-danger"></i></a>
                                                </span>
                </div>
            </div>
        </div>
        <!-- Comment Row -->
        <div class="d-flex flex-row comment-row">
            <div class="p-2"><span class="round"><img src="../assets/images/users/3.jpg" alt="user" width="50"></span></div>
            <div class="comment-text w-100">
                <h5>Johnathan Doeting</h5>
                <p class="mb-1">Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has beenorem Ipsum is simply dummy text of the printing and type setting industry.</p>
                <div class="comment-footer">
                    <span class="text-muted float-right">April 14, 2016</span>
                    <span class="label label-light-danger">Rejected</span>
                    <span class="action-icons">
                                                    <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                    <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                                    <a href="javascript:void(0)"><i class="ti-heart"></i></a>
                                                </span>
                </div>
            </div>
        </div>
        <!-- Comment Row -->
        <div class="d-flex flex-row comment-row">
            <div class="p-2"><span class="round"><img src="../assets/images/users/4.jpg" alt="user" width="50"></span></div>
            <div class="comment-text w-100">
                <h5>James Anderson</h5>
                <p class="mb-1">Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has beenorem Ipsum is simply dummy text of the printing and type setting industry..</p>
                <div class="comment-footer">
                    <span class="text-muted float-right">April 14, 2016</span>
                    <span class="label label-light-info">Pending</span>
                    <span class="action-icons">
                                                        <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                        <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                                        <a href="javascript:void(0)"><i class="ti-heart"></i></a>
                                                    </span>
                </div>
            </div>
        </div>
    </div>
</div>